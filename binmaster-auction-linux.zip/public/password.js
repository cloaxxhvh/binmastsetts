const password = document.getElementById('password')

password.oninput = (ev) => {
    console.log('Password changed')
    console.log(ev.target.value)
    localStorage.setItem('password', ev.target.value)
}